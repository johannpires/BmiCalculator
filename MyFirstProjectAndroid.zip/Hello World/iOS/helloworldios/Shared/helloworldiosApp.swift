//
//  helloworldiosApp.swift
//  Shared
//
//  Created by Johann Pires on 15/01/2023.
//

import SwiftUI

@main
struct helloworldiosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
