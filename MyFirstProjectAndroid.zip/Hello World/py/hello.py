inp = input('European floor: ')
euf = int(inp)
usf = euf + 1
print('US floor:', usf)
